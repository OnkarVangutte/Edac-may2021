import java.util.*;
class CondOp
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a,b,c,n;
		System.out.println("Do you want A Max Number Among Two Numbers or Three Numbers?");
		n=sc.nextInt();
		
		if(n==2)
		{
		System.out.println("Enter Two Number");
		a= sc.nextInt();
		b= sc.nextInt();
		int max=(a>b)?a:b;
		System.out.println("Max :"+max);
		}
		else
		{
		System.out.println("Enter Three Number");
		a= sc.nextInt();
		b= sc.nextInt();
		c= sc.nextInt();
		int max=((a>b)&&(a>c))?a:((b>a)&&(b>c))?b:c;
		System.out.println("Max :"+max);
		}
	}
}
