class Typecasting3
{
	public static void main(String args[])
	{
		short b=(byte)125;
		System.out.println(b);
	}
}