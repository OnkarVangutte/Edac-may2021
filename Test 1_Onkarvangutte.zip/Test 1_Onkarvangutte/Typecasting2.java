class Typecasting2
{
	public static void main(String args[])
	{
		float b=(int)25;
		System.out.println(b);
	}
}