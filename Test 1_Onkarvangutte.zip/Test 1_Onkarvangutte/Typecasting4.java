class Typecasting4
{
	public static void main(String args[])
	{
		int b=(long)128L;
		System.out.println(b);
	}
}