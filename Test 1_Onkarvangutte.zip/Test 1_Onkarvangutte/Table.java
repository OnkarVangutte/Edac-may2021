import java.util.*;
class Table
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a,b,c;
		System.out.println("Enter A Number");
		a= sc.nextInt();
		for(b=1;b<=10;b++)
		{
			c= a*b;
			System.out.println(a+"X"+b+"="+c);
		}
	}
}