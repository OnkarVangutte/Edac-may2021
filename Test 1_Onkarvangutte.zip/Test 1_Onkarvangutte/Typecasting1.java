class Typecasting1
{
	public static void main(String args[])
	{
		byte b=(int)20;
		System.out.println(b);
	}
}