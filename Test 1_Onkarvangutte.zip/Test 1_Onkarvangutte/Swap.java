import java.util.*;
class Swap
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a,b,temp;
		System.out.print("Enter Numbers To Swap");
		a= sc.nextInt();
		b= sc.nextInt();
		
		System.out.print("Numbers Before Swap :"+a);
		System.out.println(" "+b);
		
		temp=a;
		a=b;
		b=temp;
		
		System.out.print("Numbers After Swap :"+a);
		System.out.println(" "+b);
	}
}