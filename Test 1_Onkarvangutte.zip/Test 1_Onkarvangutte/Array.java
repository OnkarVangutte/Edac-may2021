class Array
{
	public static void main(String args[])
	{
		int a1[]= new int[]{1,2,3,4,5};
		System.out.print("Array in reverse form: ");
		for(int i=4;i>=0;i--)
		{
			System.out.print(" "+a1[i]);
		}
	}
}